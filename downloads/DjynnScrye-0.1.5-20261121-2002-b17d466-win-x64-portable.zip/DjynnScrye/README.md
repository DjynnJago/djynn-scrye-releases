# Djynn Scrye

Part of **Djynn Ex Machina** by **Digital Djynn**. Shows which Djynn Ex Machina apps this PC can run,
and for the ones it can't, exactly what is missing and how to fix it. It also summarises the PC:
Windows, CPU, RAM, graphics (VRAM, DirectX), storage, BIOS/UEFI, Secure Boot, TPM, VBS,
virtualization, power settings, and the software the apps use (.NET, Python, OBS, Ollama, AI CLIs).

- Read-only: it never changes Windows or BIOS settings. *Reboot to BIOS* restarts into firmware setup
  only after asking.
- Offline: nothing is sent anywhere. *Send to Digital Djynn support* opens an email you send yourself.
- Reports are privacy-checked (user name, personal folders and computer name removed).

Version `0.1.x` alpha. Windows 10 1809+ / 11, x64. Self-contained: no .NET install needed.

## App catalog

`catalog/apps.json` lists each app with its requirements (Windows build, RAM, VRAM, disk, DirectX,
.NET runtimes, Python, programs, command-line tools, virtualization, network, manual items) and where
they came from. Apps whose requirements are not published are shown as "Can't check yet". A copy ships
as `apps.json` next to the exe: edit it to update the list without rebuilding.

## Build

Double-click **`Build Djynn Scrye.cmd`** (needs the .NET 8 SDK; Inno Setup 6 for the
installer). Or:

```powershell
dotnet test tests/DjynnScrye.Tests -c Release
powershell -ExecutionPolicy Bypass -File packaging/build-release.ps1
```

Version numbers come from `VERSION` (0.1.1, 0.1.2 … 0.1.100, then 0.2.0); dates appear only in package
names. The older `relay/` folder (online report relay) is not used by this version.
