# Djynn Scrye: licences

Djynn Scrye © 2026 Digital Djynn (Djynn Ex Machina). All rights reserved.

| Component | Use | Licence |
|---|---|---|
| .NET 8 runtime and Windows Desktop runtime (WPF), bundled | Runs the app | MIT |
| System.Management 8.0.0 (Microsoft) | Reads Windows hardware information (WMI) | MIT |

Development only: xunit (Apache-2.0), Microsoft.NET.Test.Sdk (MIT). Installer: Inno Setup.
